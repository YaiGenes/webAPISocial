﻿using System;

namespace entityFrameworkTest.Data.Repositories
{
    internal interface ISubComponentRepository : IRepository<SubcomponentEntity, Guid>
    {
    }
}
