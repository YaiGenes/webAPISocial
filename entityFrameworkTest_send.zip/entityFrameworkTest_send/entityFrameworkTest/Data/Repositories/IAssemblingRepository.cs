﻿using System;

namespace entityFrameworkTest.Data.Repositories
{
    public interface IAssemblingRepository : IRepository<AssemblingEntity, Guid>
    {
    }
}
