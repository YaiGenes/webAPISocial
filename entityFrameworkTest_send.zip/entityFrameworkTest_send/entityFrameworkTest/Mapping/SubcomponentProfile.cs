﻿using AutoMapper;
namespace entityFrameworkTest.Mapping
{
    public class SubcomponentProfile : Profile
    {
    }
}
