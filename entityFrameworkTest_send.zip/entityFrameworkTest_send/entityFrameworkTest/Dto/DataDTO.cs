﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace entityFrameworkTest.Dto
{
    public class DataDTO
    {
        public IEnumerable<GolgiComplexDto> Data { get; set; }
    }
}
