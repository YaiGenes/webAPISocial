﻿
namespace entityFrameworkTest.Dto
{
    public class SubcomponentDTO
    {
        public string Type { get; set; }
        public double Energy { get; set; }
    }
}
