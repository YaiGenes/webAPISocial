﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace entityFrameworkTest.Dto
{
    public class CheckpointDTO
    {
        public bool Chaperonine { get; set; }
        public bool HSP80 { get; set; }
        public bool Ubiquitination { get; set; }
    }
}
