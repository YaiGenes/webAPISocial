﻿
using ServerMaintainance.Server;
using ServerMaintainance.Validator;
using System;
using System.Collections.Generic;

namespace ServerMaintainance
{
    internal class Program
    {
        static void Main()
        {
            Console.WriteLine("Welcome to the server maintainance dashboard!");

            Console.WriteLine("This is your server list");

            var servers = ServerService.GetServers();

            foreach (var item in servers)
            {
                Console.WriteLine(item.Provider + "-" + item.Type);
            }
            
            Console.WriteLine("yes if you want to check your servers status, no if you dont");

            var option = Console.ReadLine();

            if (option == "yes") 
            {
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("CHECKING SERVERS STATUS...");
            Console.ResetColor();

            RunValidation.Run();
            }
            else
            {
                Console.WriteLine("Closing App...");
            }

            Console.ReadLine();
            Console.WriteLine("Bye!");


        }
    }
}
