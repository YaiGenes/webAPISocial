﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace ServerMaintainance.Server
{
    public class Servers
    {
        [JsonPropertyName("id")]
        public string Id { get; set; }
        [JsonPropertyName("type")]
        public string Type { get; set; }
        [JsonPropertyName("provider")]
        public string Provider { get; set; }
        [JsonPropertyName("cpu")]
        public int Cpu { get; set; }
        [JsonPropertyName("bandwidth")]
        public int Bandwidth { get; set; }
        [JsonPropertyName("hdd")]
        public int Hdd { get; set; }
        [JsonPropertyName("ram")]
        public int Ram { get; set; }
        [JsonPropertyName("bio")]
        public int Bio { get; set; }
        [JsonPropertyName("controllers")]
        public int Controllers { get; set; }
        [JsonPropertyName("virtual")]
        public int Virtual { get; set; }
    }
}
