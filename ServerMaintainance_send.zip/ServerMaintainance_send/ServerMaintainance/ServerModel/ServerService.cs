﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace ServerMaintainance.Server
{
    public class ServerService
    {
        public static IEnumerable<Servers> GetServers()
        {
            var assembly = typeof(ServerService).GetTypeInfo().Assembly;
            Stream resource = assembly.GetManifestResourceStream("ServerMaintainance.ServerModel.server.json");
            try
            {
                return JsonSerializer.DeserializeAsync<IEnumerable<Servers>>(resource).Result;
            }
                catch (Exception)
            {
                return Enumerable.Empty<Servers>();
            }
        }
    }
}
