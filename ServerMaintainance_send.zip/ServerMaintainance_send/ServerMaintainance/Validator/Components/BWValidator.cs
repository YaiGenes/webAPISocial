﻿using ServerMaintainance.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServerMaintainance.Validator
{
    public class BWValidator
    {

        EnumThreshold threshold = new EnumThreshold();

        public void CheckBW()
        {
            var serverService = ServerService.GetServers();

            ValidationResults.PassedValidation = serverService.Where(p => p.Bandwidth < threshold.BANDWIDTH);
            ValidationResults.FailedValidation = serverService.Where(n => n.Bandwidth > threshold.BANDWIDTH);

            ValidationResults.PassedValidation.ToList().ForEach(p => ValidationResults.PASSValidations.Add(Guid.NewGuid() + "---" + p.Provider + "-" + p.Type  + "-" + p.Id + "-" + EnumComponents.BANDWIDTH, p.Bandwidth));
            ValidationResults.FailedValidation.ToList().ForEach(p => ValidationResults.FAILValidations.Add(Guid.NewGuid() + "---" + p.Provider + "-" + p.Type + "-" + p.Id + "-" + EnumComponents.BANDWIDTH, p.Bandwidth));
            
        }
    }
}
