﻿using ServerMaintainance.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServerMaintainance.Validator
{
    public class CONTValidator
    {

        EnumThreshold threshold = new EnumThreshold();

        public void CheckCONTR()
        {
            var serverService = ServerService.GetServers();

            ValidationResults.PassedValidation = serverService.Where(p => p.Bio == threshold.CONTROLLER);
            ValidationResults.FailedValidation = serverService.Where(n => n.Bio != threshold.CONTROLLER);

            ValidationResults.PassedValidation.ToList().ForEach(p => ValidationResults.PASSValidations.Add(Guid.NewGuid() + "---" + p.Provider + "-" + p.Type  + "-" + p.Id + "-" + EnumComponents.CONTROLLER, p.Controllers));
            ValidationResults.FailedValidation.ToList().ForEach(p => ValidationResults.FAILValidations.Add(Guid.NewGuid() + "---" + p.Provider + "-" + p.Type + "-" + p.Id + "-" + EnumComponents.CONTROLLER, p.Controllers));
            
        }
    }
}
