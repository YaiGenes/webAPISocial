﻿using ServerMaintainance.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServerMaintainance.Validator
{
    public class CPUValidator
    {
        EnumThreshold threshold = new EnumThreshold();

        public void CheckCPU()
        {
            var serverService = ServerService.GetServers();

            ValidationResults.PassedValidation = serverService.Where(p => p.Cpu < threshold.CPU);
            ValidationResults.FailedValidation = serverService.Where(n => n.Cpu > threshold.CPU);
            
            ValidationResults.PassedValidation.ToList().ForEach(p => ValidationResults.PASSValidations.Add(Guid.NewGuid()+"---"+p.Provider + "-" + p.Type + "-" + p.Id + "-" + EnumComponents.CPU, p.Cpu));
            ValidationResults.FailedValidation.ToList().ForEach(p => ValidationResults.FAILValidations.Add(Guid.NewGuid() + "---" + p.Provider + "-" + p.Type + "-" + p.Id + "-" + EnumComponents.CPU, p.Cpu));

            
        }
    }
}
