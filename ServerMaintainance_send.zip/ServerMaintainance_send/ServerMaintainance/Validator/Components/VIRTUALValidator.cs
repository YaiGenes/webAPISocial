﻿using ServerMaintainance.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServerMaintainance.Validator
{
    public class VIRTUALValidator
    {

        EnumThreshold threshold = new EnumThreshold();

        public void CheckVIRTUAL()
        {
            var serverService = ServerService.GetServers();

            ValidationResults.PassedValidation = serverService.Where(p => p.Virtual == threshold.VIRTUAL);
            ValidationResults.FailedValidation = serverService.Where(n => n.Virtual != threshold.VIRTUAL);

            ValidationResults.PassedValidation.ToList().ForEach(p => ValidationResults.PASSValidations.Add(Guid.NewGuid() + "---" + p.Provider + "-" + p.Type  + "-" + p.Id + "-" + EnumComponents.VIRTUAL, p.Virtual));
            ValidationResults.FailedValidation.ToList().ForEach(p => ValidationResults.FAILValidations.Add(Guid.NewGuid() + "---" + p.Provider + "-" + p.Type + "-" + p.Id + "-" + EnumComponents.VIRTUAL, p.Virtual));
            
        }
    }
}
