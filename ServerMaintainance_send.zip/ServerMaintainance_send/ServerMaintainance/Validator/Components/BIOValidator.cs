﻿using ServerMaintainance.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServerMaintainance.Validator
{
    public class BIOValidator
    {

        EnumThreshold threshold = new EnumThreshold();

        public void CheckBIO()
        {
            var serverService = ServerService.GetServers();

            ValidationResults.PassedValidation = serverService.Where(p => p.Bio == threshold.BIOUPDATED);
            ValidationResults.FailedValidation = serverService.Where(n => n.Bio != threshold.BIOUPDATED);

            ValidationResults.PassedValidation.ToList().ForEach(p => ValidationResults.PASSValidations.Add(Guid.NewGuid() + "---" + p.Provider + "-" + p.Type  + "-" + p.Id + "-" + EnumComponents.BIO, p.Bio));
            ValidationResults.FailedValidation.ToList().ForEach(p => ValidationResults.FAILValidations.Add(Guid.NewGuid() + "---" + p.Provider + "-" + p.Type + "-" + p.Id + "-" + EnumComponents.BIO, p.Bio));
            
        }
    }
}
