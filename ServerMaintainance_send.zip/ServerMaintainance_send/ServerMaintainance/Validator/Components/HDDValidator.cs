﻿using ServerMaintainance.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServerMaintainance.Validator
{
    public class HDDValidator
    {

        EnumThreshold threshold = new EnumThreshold();

        public void CheckHDD()
        {
            var serverService = ServerService.GetServers();

            ValidationResults.PassedValidation = serverService.Where(p => p.Hdd < threshold.HDD);
            ValidationResults.FailedValidation = serverService.Where(n => n.Hdd > threshold.HDD);
            
            ValidationResults.PassedValidation.ToList().ForEach(p => ValidationResults.PASSValidations.Add(Guid.NewGuid()+"---"+p.Provider + "-" + p.Type + "-" + p.Id + "-" + EnumComponents.HDD, p.Hdd));
            ValidationResults.FailedValidation.ToList().ForEach(p => ValidationResults.FAILValidations.Add(Guid.NewGuid() + "---" + p.Provider + "-" + p.Type + "-" + p.Id + "-" + EnumComponents.HDD, p.Hdd));

            
        }
    }
}
