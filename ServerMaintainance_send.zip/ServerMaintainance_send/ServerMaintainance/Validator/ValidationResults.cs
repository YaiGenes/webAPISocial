﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServerMaintainance.Validator
{
    public class ValidationResults
    {
        public static Dictionary<string, int> PASSValidations = new();
        public static Dictionary<string, int> FAILValidations = new();
        public static IEnumerable<ServerMaintainance.Server.Servers> PassedValidation = new List<ServerMaintainance.Server.Servers>();
        public static IEnumerable<ServerMaintainance.Server.Servers> FailedValidation = new List<ServerMaintainance.Server.Servers>();

    }
}
