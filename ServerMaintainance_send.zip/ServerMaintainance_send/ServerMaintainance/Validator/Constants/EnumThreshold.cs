﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServerMaintainance.Validator
{
    public class EnumThreshold
    {
        public int CPU { get; set; } = 80;
        public int BANDWIDTH { get; set; } = 500;
        public int RAM { get; set; } = 20;
        public int HDD { get; set; } = 90;
        public int BIOUPDATED { get; set; } = 1;
        public int CONTROLLER { get; set; } = 1;
        public int VIRTUAL { get; set; } = 1;
    }
}
