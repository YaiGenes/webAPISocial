﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServerMaintainance.Validator
{
    public enum EnumComponents
    {
        CPU,
        BANDWIDTH,
        RAM,
        HDD,
        BIO,
        CONTROLLER,
        VIRTUAL
    }
}
