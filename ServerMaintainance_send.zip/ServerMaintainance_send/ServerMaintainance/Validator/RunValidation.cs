﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServerMaintainance.Validator
{
    public static class RunValidation
    {
        public static string Run()
        {
            CPUValidator checkCPU = new CPUValidator();
            RAMValidator checkRAM = new RAMValidator();
            HDDValidator checkHDD = new HDDValidator();
            BWValidator checkBW = new BWValidator();
            VIRTUALValidator checkVIRTUAL = new VIRTUALValidator();
            CONTValidator checkCONT = new CONTValidator();
            BIOValidator checkBIO = new BIOValidator();

            checkCPU.CheckCPU();
            checkRAM.CheckRAM();
            checkHDD.CheckHDD();
            checkBW.CheckBW();
            checkCONT.CheckCONTR();
            checkVIRTUAL.CheckVIRTUAL();
            checkBIO.CheckBIO();

            foreach (var item in ValidationResults.PASSValidations)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(item.Key + "  ___  " + item.Value);
                Console.ResetColor();
            }
            foreach (var item in ValidationResults.FAILValidations)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(item.Key + "  ___  " + item.Value);
                Console.ResetColor();
            }

            string message = "Loading data";

            return message;
        }
    }
}
