﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using VuelingAutoMobileFaktory.Configuration;

namespace VuelingAutoMobileFaktory.Domain
{
    public class OrderComponent
    {
        public string ComponentType { get; set; }
        public List<OrderSubComponent> Subcomponents { get; set; }
        public double PriceIncrement { get; set; }
        public int NumComponents { get; set; }
        public string Color { get; set; }
        public List<string> Tests { get; set; }
    }
}
