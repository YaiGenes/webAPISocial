﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VuelingAutoMobileFaktory.Domain
{
    public class OrderSubComponent
    {
        public string Type { get; set; }
        public double Price { get; set; }
    }
}
