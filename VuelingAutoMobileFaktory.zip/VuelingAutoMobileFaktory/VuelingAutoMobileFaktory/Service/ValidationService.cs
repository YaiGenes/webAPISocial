﻿using System.Collections.Generic;

namespace VuelingAutoMobileFaktory.Service
{
    public class ValidationService
    {
        public ValidationService(List<bool> validations, out string message)
        {
            int count = 0;
            foreach (var item in validations)
            {
                if (item)
                {
                    count++;
                }
            }
            if (count == validations.Count)
                message = "Validation passed";
            else
            {
                message = "Validation failed";
            }
        }

    }
}
