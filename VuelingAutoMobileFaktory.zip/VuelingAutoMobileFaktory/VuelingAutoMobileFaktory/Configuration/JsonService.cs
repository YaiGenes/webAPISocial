﻿using System;
using System.Net;
using System.Buffers.Text;
using System.Buffers;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using VuelingAutoMobileFaktory.Domain;
using Newtonsoft.Json;

namespace VuelingAutoMobileFaktory.Configuration
{
    public class JsonService
    {
        public OrderInfo GetOrder(string path)
        {
            var webClient = new WebClient();
            var stringJson = webClient.DownloadString(path);


            return JsonConvert.DeserializeObject<OrderInfo>(stringJson);
        }
    }
}
