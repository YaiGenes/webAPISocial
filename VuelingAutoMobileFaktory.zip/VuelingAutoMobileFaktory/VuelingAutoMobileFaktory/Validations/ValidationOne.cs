﻿
namespace VuelingAutoMobileFaktory.Validations
{
    internal class ValidationOne : IValidation
    {
        public string ValidationType = "Test1";

        public bool Validate(bool entry, out string errMessage)
        {
            if (entry == false)
            {
                errMessage = $"The product doesnt accomplish the {ValidationType}";
                return false;
            }
            else
                errMessage = $"The product accomplished the {ValidationType}"; ;
                return true;
        }

    }
}
