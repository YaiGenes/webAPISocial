﻿namespace VuelingAutoMobileFaktory
{
    public interface IValidation
    {
        bool Validate(bool entry, out string errMessage);
    }
}
