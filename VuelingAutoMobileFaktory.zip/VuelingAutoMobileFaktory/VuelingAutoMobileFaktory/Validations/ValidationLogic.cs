﻿using System.Collections.Generic;
using VuelingAutoMobileFaktory.Domain;

namespace VuelingAutoMobileFaktory.Validations
{
    public class ValidationLogic
    {
        public bool GetValidationMessage (List<OrderComponent> orderComponent, string testType, out string resMessage)
        {
            int count = 0;
            int arrayTestLength = 0;

            foreach (var item in orderComponent)
            {
                item.Tests.ForEach(test =>
                {
                    if (test == testType)
                    {
                        count++;
                    }
                });
                arrayTestLength = item.Tests.Count;
            }

            if (count == arrayTestLength)
            {
                resMessage = $"All the components passed {testType}";
                return true;
            }
            else if (count > 0 && count < arrayTestLength)
            {
                resMessage = $"At least one of your components doesnt passed {testType}";
                return false;
            }
            else if (count > arrayTestLength)
            {
                resMessage = $"Error, at least one of your component has repeated {testType}";
                return false;
            }
            else
                resMessage = $"Any of your components passed {testType}";
                return false;
        }
    }
}
