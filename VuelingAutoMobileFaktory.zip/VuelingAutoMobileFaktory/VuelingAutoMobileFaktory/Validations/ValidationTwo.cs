﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VuelingAutoMobileFaktory.Domain;

namespace VuelingAutoMobileFaktory.Validations
{
    internal class ValidationTwo : IValidation
    {
        public string ValidationType = "Test2";

        public bool Validate(bool entry, out string errMessage)
        {
            if (!entry)
            {
                errMessage = $"The product doesnt accomplish the {ValidationType}";
                return false;
            }
            else
                errMessage = $"The product accomplished the {ValidationType}"; ;
            return true;
        }
    }
}
