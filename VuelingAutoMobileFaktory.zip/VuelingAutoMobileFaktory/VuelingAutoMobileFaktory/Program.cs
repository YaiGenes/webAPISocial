﻿using System;
using System.Collections.Generic;
using VuelingAutoMobileFaktory.Configuration;
using VuelingAutoMobileFaktory.Service;
using VuelingAutoMobileFaktory.Validations;

namespace VuelingAutoMobileFaktory
{
    public class Program
    {
        static void Main()
        {

            var getOrder = new JsonService();
            var res = getOrder.GetOrder(@"C:\Users\yaise\source\repos\VuelingAutoMobileFaktory\VuelingAutoMobileFaktory\Configuration\orderdata.json").Detail;

            ValidationOne validationOne = new ValidationOne();
            ValidationTwo validationTwo = new ValidationTwo();
            ValidationThree validationThree = new ValidationThree();

            ValidationLogic getValMessage = new ValidationLogic();
         
            var logicValueOne = getValMessage.GetValidationMessage(res, validationOne.ValidationType, out string j);
            var logicValueTwo = getValMessage.GetValidationMessage(res, validationTwo.ValidationType, out string k);
            var logicValueThree = getValMessage.GetValidationMessage(res, validationThree.ValidationType, out string l);

            var validationTest1 = validationOne.Validate(logicValueOne, out j);
            var validationTes2 = validationTwo.Validate(logicValueTwo, out k);  
            var validationTe3 = validationThree.Validate(logicValueThree, out l);

            new ValidationService(new List<bool> { validationTest1, validationTes2, validationTe3 }, out j );
            Console.WriteLine(j);


        }
    }
}