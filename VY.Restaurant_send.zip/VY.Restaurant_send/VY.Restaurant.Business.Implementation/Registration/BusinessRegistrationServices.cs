﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VY.Restaurant.Business.Contracts.Services;
using VY.Restaurant.Business.Implementation.Services;
using VY.Restaurant.Data.Implementation.Registration;

namespace VY.Restaurant.Business.Implementation.Registration
{
    public static class BusinessRegistrationServices
    {
        public static IServiceCollection AddBusinessServices(this IServiceCollection services)
        {
            services.AddTransient<IReservationProcessor, ReservationProcessor>();
            return services;
        }
    }
}
