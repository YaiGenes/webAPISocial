﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VY.Restaurant.Business.Contracts.Services;
using VY.Restaurant.Dtos;

namespace VY.Restaurant.Business.Implementation.Services
{
    public class ReservationProcessor: IReservationProcessor
    {
        private readonly ILogger<ReservationProcessor> logger;
        private readonly IEnumerable<IValidation<ValidationContext>> validations;

        public ReservationProcessor(ILogger<ReservationProcessor> logger, IEnumerable<IValidation<ValidationContext>> validations)
        {
            this.logger = logger;
            this.validations = validations;
        }

        public void Process()
        {
            throw new NotImplementedException();
        }

        private ReservationDTO GetOrderData(string csvFile) 
        {
            //csv file transformation with ReadAllLines
            
        }

        //public static ReservationDTO CsvToObject(string[] csvLine)
        //{
        //    ReservationDTO dto = new ReservationDTO();
        //    dto.Id = Guid.Parse(cvsLine[0]);
        //    dto.Date = Convert.ToDateTime(csvLine[1]);
        //    dto.Time = Convert.ToDateTime(csvLine[2]);
        //    dto.GroupId = Guid.Parse(cvsLine[3]);
        //    dto.TableId = Guid.Parse(cvsLine[4]);

        //    return dto;
        //}
    }
}
