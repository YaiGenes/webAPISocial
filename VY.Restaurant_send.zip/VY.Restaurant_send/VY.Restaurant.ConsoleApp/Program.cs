﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.IO;
using VY.Restaurant.Business.Implementation.Registration;

namespace VY.Restaurant.ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var host = CreateHostBuilder(args).Build();
            //start
        }

        private static IHostBuilder CreateHostBuilder(string[] args)
        {
            return Host.CreateDefaultBuilder(args)
                        .ConfigureAppConfiguration((hostContext, config) =>
                        {
                            config.AddJsonFile(Path.Combine(Path.Combine(hostContext.HostingEnvironment.ContentRootPath, "Configuration"), "settings.json"));
                            config.AddEnvironmentVariables();
                            if (args != null)
                                config.AddCommandLine(args);

                        })
                        .ConfigureServices((hostContext, services) =>
                        {
                            services.AddBusinessServices();
                        })
                        .ConfigureLogging((hostContext, logging) =>
                        {
                            logging.AddConsole();
                        });

        }
    }
}
