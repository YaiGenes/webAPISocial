﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VY.Restaurant.Dtos
{
    public class ReservationDTO
    {
        public Guid Id { get; set; }
        public DateTime Date { get; set; }
        public DateTime Time { get; set; }
        public Guid GroupId { get; set; }
        public Guid TableId { get; set; }
    }
}
