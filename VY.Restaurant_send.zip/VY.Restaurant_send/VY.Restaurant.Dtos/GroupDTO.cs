﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VY.Restaurant.Dtos
{
    public class GroupDTO
    {
        public Guid Id { get; set; }
        public int GroupNumber { get; set; }
    }
}
