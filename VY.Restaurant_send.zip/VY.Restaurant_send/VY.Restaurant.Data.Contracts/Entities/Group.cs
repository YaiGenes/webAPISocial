﻿using System;
using System.Collections.Generic;

#nullable disable

namespace VY.Restaurant.Data.Contracts.Entities
{
    public partial class Group
    {
        public Guid Id { get; set; }
        public int? GroupNumber { get; set; }
    }
}
