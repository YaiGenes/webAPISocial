﻿using System;
using System.Collections.Generic;

#nullable disable

namespace VY.Restaurant.Data.Contracts.Entities
{
    public partial class Reservation
    {
        public Guid Id { get; set; }
        public DateTime Date { get; set; }
        public TimeSpan Time { get; set; }
        public Guid GroupId { get; set; }
        public Guid TableId { get; set; }
    }
}
