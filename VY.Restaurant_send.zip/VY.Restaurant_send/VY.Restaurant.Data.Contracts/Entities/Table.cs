﻿using System;
using System.Collections.Generic;

#nullable disable

namespace VY.Restaurant.Data.Contracts.Entities
{
    public partial class Table
    {
        public Guid Id { get; set; }
        public int Capacity { get; set; }
    }
}
