﻿using System;
using System.Collections.Generic;

#nullable disable

namespace VY.Restaurant.Data.Contracts.Entities
{
    public partial class Person
    {
        public Guid? Id { get; set; }
        public string Name { get; set; }
        public Guid? GroupId { get; set; }
    }
}
